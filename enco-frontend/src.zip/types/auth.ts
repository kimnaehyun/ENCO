// src/types/auth.ts
import { NativeStackScreenProps } from "@react-navigation/native-stack";

export type AuthStackParamList = {
  AuthLanding: undefined;
  Login: undefined;
  SignupForm: undefined;
  SignupPinSetup: {
    name: string;
    birth: string;
    phone: string;
    email: string;
  };
};

export type AuthStackScreenProps<T extends keyof AuthStackParamList> =
  NativeStackScreenProps<AuthStackParamList, T>;

export type Step = "name" | "birth" | "phone" | "email" | "done";