package io.ssafy.chat.chatbot.controller;

public class ChatBotContoller {
}
