package io.ssafy.chat.chatbot.service;

public class ChatBotService {
}
